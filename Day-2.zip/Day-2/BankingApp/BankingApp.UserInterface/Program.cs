﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using BankingApp.Entities;

namespace BankingApp.UserInterface
{
    class Program
    {
        static Account CreateAccount()
        {
            Console.Write("Name: ");
            string name = Console.ReadLine();

            Console.Write("Id: ");
            int id = int.Parse(Console.ReadLine());

            Console.Write("Balance: ");
            decimal balance = decimal.Parse(Console.ReadLine());

            Account account = new Account(name, id, balance);
            return account;
        }
        static decimal GetAmount()
        {
            Console.Write("\nenter transfer amount: ");
            decimal amount = decimal.Parse(Console.ReadLine());
            return amount;
        }

        static void Main()
        {

            Account debitAccount = CreateAccount();
            Account creditAccount = CreateAccount();
            decimal amount = GetAmount();

            bool debitStatus;
            decimal debitAccountBalance = debitAccount.DebitFromAccount(
                amount,
                out debitStatus);

            decimal creditAccountBalance = 0;

            if (debitStatus)
            {
                creditAccountBalance = creditAccount.CreditToAccount(amount);
                Console.WriteLine(debitAccountBalance);
                Console.WriteLine(creditAccountBalance);
            }
            else
                Console.WriteLine("transaction failed");
            /*
        string date = Console.ReadLine();
        //DateTime dt = DateTime.Parse(date);
        //Console.WriteLine(dt.ToShortDateString());
        DateTime dt;
        bool possible = DateTime.TryParse(date, out dt);
        //Console.WriteLine(dt.ToShortDateString());
        if (possible)
            Console.WriteLine(dt.ToShortDateString());
        else
            Console.WriteLine("not possible to format");
            */
        }
    }
}
