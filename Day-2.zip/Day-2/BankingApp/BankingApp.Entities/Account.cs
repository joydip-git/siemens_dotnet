﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingApp.Entities
{
    public class Account
    {
        string accountHolderName;
        long accountId;
        decimal currentBalance;
        public const decimal MINIMUMBALANCE = 1000;

        public Account()
        {

        }
        public Account(string name, long id, decimal balance)
        {
            accountHolderName = name;
            accountId = id;
            currentBalance = balance;
        }
        public decimal CreditToAccount(decimal amount)
        {
            currentBalance += amount;
            return currentBalance;
        }
        public decimal DebitFromAccount(decimal amount, out bool status)
        {

            if (amount > 0)
            {
                if (amount < currentBalance)
                {
                    currentBalance -= amount;
                    status = true;
                }
                else
                    status = false;
            }
            else
                status = false;

            return currentBalance;
        }
    }
}
