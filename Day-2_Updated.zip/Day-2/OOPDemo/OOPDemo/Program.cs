﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPDemo
{
    class Program
    {
        static void Create()
        {
            Console.WriteLine(Student.GetSchool());
            /*
            Student student = null;

            for (int i = 0; i < 1; i++)
            {
                Console.Write("name: ");
                string name = Console.ReadLine();

                Console.Write("id: ");
                int id = int.Parse(Console.ReadLine());

                Console.Write("marks: ");
                double marks = double.Parse(Console.ReadLine());

                student = new Student(name, id, marks);
                //person = new Person();
                
                string info = student.GetInformation();
                Console.WriteLine(info);
            }
            */
            
        }
        static void Main()
        {
           Program.Create();
        }
    }
}
