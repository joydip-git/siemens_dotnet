﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPDemo
{
    class Student
    {
        private static string schoolName = "abcd";
        private string studentName;
        private int studentId;
        private double studentMarks;

        static Student()
        {
            Console.WriteLine(schoolName);
            schoolName = "sahgxsahg";
            Console.WriteLine(schoolName);
        }
        //default constructor
        public Student()
        { 
        }

        //parameterized constructor
        public Student(string name, int id, double marks) //: this()
        {
            studentName = name;
            studentId = id;
            studentMarks = marks;
        }
        public string GetInformation()
        {
            return $"Name: {studentName}, Id:{studentId} school: {schoolName} and marks:{studentMarks}";
        }
        public bool HasPassed()
        {
            if (studentMarks > 70)
                return true;
            else
                return false;
        }
        public static string GetSchool()
        {            
            return schoolName;
        }
    }
}
