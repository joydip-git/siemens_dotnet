﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayDemo
{
    class Program
    {
        static void Main()
        {
            //CreateOneDimensionalArray();
            //CreateTwoDimensionalArray();
            CreateStringArray();
            //int a = 10;
            //int b = 20;
            //int c = a > b ? a : b;
        }

        private static void CreateStringArray()
        {
            string[] names = new string[3];
            for (int i = 0; i < names.Length; i++)
            {
                //if (names[i] == null)
                //    Console.WriteLine("NULL");
                //else
                //    Console.WriteLine(names[i]);

                //Console.WriteLine(names[i] == null ? "NULL" : names[i]);
                Console.Write("Name: ");
                names[i] = Console.ReadLine();
            }
            foreach (string item in names)
            {
                Console.WriteLine(item);
            }
        }

        private static void CreateTwoDimensionalArray()
        {
            Console.Write("How many rows? ");
            int rows = int.Parse(Console.ReadLine());

            Console.Write("How many elements per row? ");
            int elements = int.Parse(Console.ReadLine());

            int[,] numbers = new int[rows, elements];

            for (int rowIndex = 0; rowIndex < rows; rowIndex++)
            {
                for (int elementIndex = 0; elementIndex < elements; elementIndex++)
                {
                    Console.Write($"enter value at numbers[{rowIndex},{elementIndex}]: ");
                    int val = int.Parse(Console.ReadLine());
                    numbers[rowIndex, elementIndex] = val;
                }
            }
            Console.WriteLine();
            for (int rowIndex = 0; rowIndex < rows; rowIndex++)
            {
                for (int elementIndex = 0; elementIndex < elements; elementIndex++)
                {
                    Console.WriteLine($"value at numbers[{rowIndex},{elementIndex}]: {numbers[rowIndex, elementIndex]}");
                }
            }
        }

        private static void CreateOneDimensionalArray()
        {
            //Array arr = new Array();
            Console.Write("How many values? ");
            int count = int.Parse(Console.ReadLine());

            int[] arr = new int[count];

            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine($"value at arr[{i}]: {arr[i]}");
            }
            Console.WriteLine();
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write($"enter value at arr[{i}]: ");
                int val = int.Parse(Console.ReadLine());
                arr[i] = val;
            }
            Console.WriteLine();
            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine($"value at arr[{i}]: {arr[i]}");
            }
        }
    }
}
