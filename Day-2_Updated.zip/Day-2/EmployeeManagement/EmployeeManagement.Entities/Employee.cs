﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagement.Entities
{
    public class Employee
    {
        private string employeeName;
        private int employeeId;
        private decimal basicPayment;
        private decimal daPayment;
        private decimal hraPayment;
        private decimal totalSalary;
        string projectName;

        public Employee() { }        
        public Employee(string name, int id, decimal basic, decimal da, decimal hra, string project)
        {
            employeeId = id;
            employeeName = name;
            basicPayment = basic;
            daPayment = da;
            hraPayment = hra;
            projectName = project;
        }
        //property with ONLY get accessor
        public decimal TotalSalary { get => totalSalary; }
        public string EmployeeName { get => employeeName; set => employeeName = value; }
        public int EmployeeId { get => employeeId; set => employeeId = value; }
        public decimal BasicPayment { get => basicPayment; set => basicPayment = value; }
        public decimal DaPayment { get => daPayment; set => daPayment = value; }
        public decimal HraPayment { get => hraPayment; set => hraPayment = value; }
        public string ProjectName { get => projectName; set => projectName = value; }

        public void CalculateSalary()
        {
            totalSalary = basicPayment + daPayment + hraPayment;
        }
    }
}
