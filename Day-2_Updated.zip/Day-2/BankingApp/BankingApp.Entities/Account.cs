﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingApp.Entities
{
    public class Account
    {
        private long accountId;
        private string accountHolderName;
        decimal currentBalance;
        public const decimal MINIMUMBALANCE = 1000;

        public Account() { }
        //optional argument (with default value) - 4.0 - 2010- C#4.0
        public Account(string name, long id, decimal balance = 0)
        {
            accountHolderName = name;
            accountId = id;
            currentBalance = balance;
        }
        public void CreditToAccount(decimal amount)
        {
            currentBalance += amount;
        }
        public void DebitFromAccount(decimal amount, out bool status)
        {

            if (amount > 0)
            {
                if (amount < currentBalance)
                {
                    currentBalance -= amount;
                    status = true;
                }
                else
                    status = false;
            }
            else
                status = false;

            //return currentBalance;
        }

        public decimal CurrentBalance
        {
            //public void SetCurrentBalance(decimal balance)
            set
            {
                currentBalance = value;
            }
            //public decimal GetCurrentBalance()
            get
            {
                return currentBalance;
            }
        }

        public string AccountHolderName
        {
            get { return accountHolderName; }
            set { accountHolderName = value; }
        }


        public long AccountId
        {
            get { return accountId; }
            set { accountId = value; }
        }
    }
}
