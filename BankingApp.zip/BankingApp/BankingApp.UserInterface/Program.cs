﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using BankingApp.Entities;

namespace BankingApp.UserInterface
{
    class Program
    {
        static Account CreateAccount()
        {
            Console.Write("Name: ");
            string name = Console.ReadLine();

            Console.Write("Id: ");
            int id = int.Parse(Console.ReadLine());

            Console.Write("Balance: ");
            decimal balance = decimal.Parse(Console.ReadLine());

            Account account = new Account(name, id);
            //account.SetCurrentBalance(balance);
            account.CurrentBalance = balance;
            return account;
        }
        static decimal GetAmount()
        {
            Console.Write("\nenter transfer amount: ");
            decimal amount = decimal.Parse(Console.ReadLine());
            return amount;
        }

        static void Main()
        {

            Account debitAccount = CreateAccount();
            Account creditAccount = CreateAccount();
            decimal amount = GetAmount();

            bool debitStatus;
            debitAccount.DebitFromAccount(amount, out debitStatus);

            if (debitStatus)
            {
                creditAccount.CreditToAccount(amount);

                //decimal debitAccountBalance = debitAccount.GetCurrentBalance();
                //decimal creditAccountBalance = creditAccount.GetCurrentBalance();

                Console.WriteLine($"{ debitAccount.AccountHolderName} has current Balance {debitAccount.CurrentBalance}");
                Console.WriteLine($"{ creditAccount.AccountHolderName} has current Balance {creditAccount.CurrentBalance}");
            }
            else
                Console.WriteLine("transaction failed");
            /*
        string date = Console.ReadLine();
        //DateTime dt = DateTime.Parse(date);
        //Console.WriteLine(dt.ToShortDateString());
        DateTime dt;
        bool possible = DateTime.TryParse(date, out dt);
        //Console.WriteLine(dt.ToShortDateString());
        if (possible)
            Console.WriteLine(dt.ToShortDateString());
        else
            Console.WriteLine("not possible to format");
            */
        }
    }
}
