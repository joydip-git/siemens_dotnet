﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleApplication
{
    //1.
    delegate bool LogicHandler(int number);

    class Logic
    {
        public static bool IsEven(int num)
        {
            return num % 2 == 0 ? true : false;
        }
        public bool IsOdd(int num)
        {
            return num % 2 != 0 ? true : false;
        }
    }
    class Program
    {

        static List<int> Filter(List<int> input, LogicHandler logicInvoker)
        {
            try
            {
                List<int> output = new List<int>();
                foreach (int item in input)
                {
                    bool isEven = logicInvoker(item);
                    if (isEven)
                    {
                        output.Add(item);
                    }
                }
                return output;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        static void Main()
        {
            //Console.WriteLine(args[0]);
            List<int> numbers = new List<int> { 1, 2, 5, 4, 9, 0, 6, 7, 3 };

            //2. 
            Logic l = new Logic();
            //LogicHandler logic = new LogicHandler(l.IsOdd);
            //LogicHandler logic = new LogicHandler(Logic.IsEven);

            //anonymous method (2.0)
            //LogicHandler logic = delegate (int x)
            //{
            //    return x > 3 ? true : false;
            //};

            //Lambda expression for anonymous method (3.0)
            //LogicHandler logic = (x) => x > 3;

            //var output = Filter(numbers, num => num % 2 == 0);
            //foreach (int item in output)
            //{
            //    Console.WriteLine(item);
            //}

            //method query
            numbers
                .OrderBy(num => num)
                .Where(num => num % 2 == 0)
                .Take(3)
                .ToList<int>()
                .ForEach(num => Console.WriteLine(num));

            //query operator syntax
            var query = from num in numbers
                        orderby num ascending
                        where num % 2 == 0
                        select num;

            query.Take(3).ToList<int>().ForEach(x => Console.WriteLine(x));

        }
    }
}
