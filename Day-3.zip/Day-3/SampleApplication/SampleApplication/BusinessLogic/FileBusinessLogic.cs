﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SampleApplication.DataAccess;

namespace SampleApplication.BusinessLogic
{
    class FileBusinessLogic
    {
        public void FetchData()
        {
            FileDataAccess dataAccess = null;

            dataAccess = new FileDataAccess();
            var data = dataAccess.GetData();
            data.Where(kv => kv.Key == "CalculatorTest");
        }
    }
}
