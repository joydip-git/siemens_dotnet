﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Collections.Specialized;
using System.IO;

namespace SampleApplication.DataAccess
{
    class FileDataAccess : IDataAccess//, IDisposable
    {
        private StreamReader reader;

        public FileDataAccess()
        {

        }

        //public void Dispose()
        //{
        //    reader.Close();
        //}

        public SortedList<string, List<string>> GetData()
        {
            SortedList<string, List<string>> testData = null;
            //NameValueCollection filePath = ConfigurationManager.AppSettings;
            //implicitly typed variable
            var settings = ConfigurationManager.AppSettings;
            var filePath = settings["filePath"];

            if (File.Exists(filePath))
            {
                using (reader = new StreamReader(filePath))
                {
                    testData = new SortedList<string, List<string>>();

                    while (reader.EndOfStream)
                    {
                        string data = reader.ReadLine();
                        if (data != null && data != string.Empty)
                        {
                            char[] splitters = new char[] { ',' };
                            string[] words = data.Split(splitters, StringSplitOptions.RemoveEmptyEntries);

                            string clsName = words[0];
                            List<string> testMethods = new List<string>();
                            for (int i = 1; i < words.Length; i++)
                            {
                                testMethods.Add(words[i]);
                            }
                            testMethods.Sort();
                            testData.Add(clsName, testMethods);
                        }
                    }
                }
            }
            return testData;
        }
    }
}
