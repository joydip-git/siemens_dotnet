﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo
{
    class Trainer : Person //derived/child class
    {
        string domainExpertise;
        public Trainer() { }
        public Trainer(string name, string subject, string domain)
            : base(name, subject)
        {
            this.domainExpertise = domain;
        }
        public string DomainExpertise { get => domainExpertise; set => domainExpertise = value; }
        //public new string PrintInformation()

        public override string PrintInformation()
        {
            return $"{base.PrintInformation()} and Expertise: { domainExpertise}";
        }
    }
}
