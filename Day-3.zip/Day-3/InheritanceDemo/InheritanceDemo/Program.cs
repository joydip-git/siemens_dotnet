﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo
{
    class Developer : Trainee
    {

    }
    class Tester : Trainee
    {

    }
    class Program
    {
        //static void Print(Trainer trainer)
        //{

        //}
        //static void Print(Trainee trainee)
        //{

        //}
        static void Print(Person person)
        {
            string personInfo = person.PrintInformation();
            Console.WriteLine(personInfo);
        }
        static void Main()
        {
            Trainer trainer = new Trainer("anil", "CSharp", "DotNet");
            Trainee trainee = new Trainee("sunil", "CSharp", "SITA");

            Print(trainer);
            Print(trainee);

            //string traineeInfo = trainee.PrintInformation();
            //string trainerInfo = trainer.PrintInformation();

            //Console.WriteLine(traineeInfo);
            //Console.WriteLine(trainerInfo);
        }
    }
}
