﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo
{
    class Person //base-class/parent-class
    {
        protected string name;
        protected string subject;

        public Person()
        {

        }
        public Person(string name, string subject)
        {
            this.name = name;
            this.subject = subject;
        }
        public string Name { get => name; set => name = value; }
        public string Subject { get => subject; set => subject = value; }

        public virtual string PrintInformation()
        {
            return $"Name: {name} and Subject: {subject}";
        }
    }
}
