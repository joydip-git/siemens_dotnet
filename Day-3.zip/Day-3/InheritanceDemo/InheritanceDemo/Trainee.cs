﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo
{
    class Trainee : Person
    {
        string projectName;
        public Trainee()
        {

        }
        public Trainee(string name, string subject, string project)
            : base(name, subject)
        {
            this.projectName = project;
        }

        public string ProjectName { get => projectName; set => projectName = value; }

        //public new string PrintInformation()
        public override string PrintInformation()
        {
            string info = base.PrintInformation();
            return $"{info} and Project:{projectName}";
        }
    }
}
