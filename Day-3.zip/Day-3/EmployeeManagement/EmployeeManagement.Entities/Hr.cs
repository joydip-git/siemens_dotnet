﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagement.Entities
{
    public class Hr : Employee
    {
        decimal gratuityPayment;

        public Hr() { }
        public Hr(string name, int id, decimal basic, decimal da, decimal hra, decimal gratuity) : base(name, id, basic, da, hra)
        {
            gratuityPayment = gratuity;
        }

        public decimal GratuityPayment { get => gratuityPayment; set => gratuityPayment = value; }

        public override void CalculateSalary()
        {
            base.CalculateSalary();
            TotalSalary += gratuityPayment;
        }
    }
}
