﻿namespace EmployeeManagement.Entities
{
    public class Developer : Employee
    {
        decimal incentivePayment;
        string projectName;

        public Developer() { }
        public Developer(string name, int id, decimal basic, decimal da, decimal hra, decimal incentive, string project)
            : base(name, id, basic, da, hra)
        {
            incentivePayment = incentive;
            projectName = project;
        }

        public decimal IncentivePayment { get => incentivePayment; set => incentivePayment = value; }

        public string ProjectName { get => projectName; set => projectName = value; }

        public override void CalculateSalary()
        {
            base.CalculateSalary();
            TotalSalary += incentivePayment;
        }
    }
}
