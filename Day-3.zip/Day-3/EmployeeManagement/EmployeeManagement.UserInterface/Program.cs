﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using EmployeeManagement.Entities;

namespace EmployeeManagement.UserInterface
{
    class Program
    {
        static int GetCount()
        {
            Console.Write("how many records? ");
            return int.Parse(Console.ReadLine());
        }
        static void PrintMenu()
        {
            Console.WriteLine("\n1. Developer");
            Console.WriteLine("2. Hr");
        }
        static int GetChoice()
        {
            Console.Write("\nEnter Choice[1/2]: ");
            return int.Parse(Console.ReadLine());
        }
        static Employee Create(int choice)
        {
            Console.Write("Name: ");
            string name = Console.ReadLine();

            Console.Write("id: ");
            int id = int.Parse(Console.ReadLine());

            Console.Write("Basic Payment: ");
            decimal basic = decimal.Parse(Console.ReadLine());

            Console.Write("Da Payment: ");
            decimal da = decimal.Parse(Console.ReadLine());

            Console.Write("Hra Payment: ");
            decimal hra = decimal.Parse(Console.ReadLine());

            Employee employee = null;
            switch (choice)
            {
                case 1:
                    Console.Write("Project Name: ");
                    string projectName = Console.ReadLine();
                    Console.Write("Incentive Payment: ");
                    decimal incentive = decimal.Parse(Console.ReadLine());
                    employee = new Developer(name, id, basic, da, hra, incentive, projectName);
                    break;

                case 2:
                    Console.Write("Gratuity Payment: ");
                    decimal gratuity = decimal.Parse(Console.ReadLine());
                    employee = new Hr(name, id, basic, da, hra, gratuity);
                    break;

                default:
                    break;
            }
            //employee = new Employee(name, id, basic, da, hra, projectName);
            //employee = new Employee();
            //employee.EmployeeId = id;
            //employee.EmployeeName = name;
            //employee.BasicPayment = basic;
            //employee.DaPayment = da;
            //employee.HraPayment = hra;
            //employee.ProjectName = projectName;

            //2007 - 3.0 - C# 3.0 (Object initializer)
            //employee = new Employee { EmployeeName = name, EmployeeId = id, BasicPayment = basic, DaPayment = da, HraPayment = hra, ProjectName = projectName };
            return employee;
        }
        static void AddEmployee(Employee[] employees)
        {
            for (int i = 0; i < employees.Length; i++)
            {
                PrintMenu();
                int choice = GetChoice();
                Employee employee = Create(choice);
                employees[i] = employee;
            }
        }
        static void AddEmployee(List<Employee> employeesList, int count)
        {
            for (int i = 0; i < count; i++)
            {
                PrintMenu();
                int choice = GetChoice();
                Employee employee = Create(choice);
                employeesList.Add(employee);
            }
        }
        static void PrintSalary(Employee[] employees)
        {
            for (int i = 0; i < employees.Length; i++)
            {
                Employee e = employees[i];
                e.CalculateSalary();
                Console.WriteLine($"\nSalary of {e.EmployeeName} is {e.TotalSalary}"); 
            }
        }
        static void PrintSalary(List<Employee> employees)
        {
            for (int i = 0; i < employees.Count; i++)
            {
                Employee e = employees[i];
                e.CalculateSalary();
                Console.WriteLine($"\nSalary of {e.EmployeeName} is {e.TotalSalary}");
            }
        }
        
        static void Main()
        {
            int recordCount = GetCount();

            //Employee[] employees = new Employee[recordCount];
            List<Employee> employeesList = new List<Employee>();

            //AddEmployee(employees);
            AddEmployee(employeesList, recordCount);

            //PrintSalary(employees);
            PrintSalary(employeesList);

            /*
            //Employee[] temp = employees;
            //employees = new Employee[recordCount + 2];
            //temp.CopyTo(employees, 0);

            Console.WriteLine($"capacity of the list is {employeesList.Capacity} right now but it contains { employeesList.Count } values");

            //Sample sample = Sample.Create();
            //Sample sample1 = Sample.Create();
            //if(sample == sample1)
            //    Console.WriteLine("same");
            */
            Console.WriteLine("\nPress enter to terminate the application...");
            Console.ReadLine();
        }
    }
}
