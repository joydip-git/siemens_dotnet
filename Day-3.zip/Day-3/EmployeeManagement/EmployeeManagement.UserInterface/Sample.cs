﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagement.UserInterface
{
    /*
     * class with private constructor
     * also only one instance of the class being created
     * this is single pattern
     */
    class Sample
    {
        private static Sample sample;

        private Sample() { }
        public static Sample Create()
        {
            if (sample == null)
                sample = new Sample();

            return sample;
        }
    }
}
