﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodOverloading
{
    class Program
    {
        static void Add(int a, int b)
        {
            Console.WriteLine(a + b);
        }
        static void Add(int a, int b, int c)
        {
            Console.WriteLine(a + b + c);
        }
        static void Add(int a, int b, long c)
        {
            Console.WriteLine(a + b + c);
        }
        static void Add(int a, long b, int c)
        {
            Console.WriteLine(a + b + c);
        }
        static void Main()
        {
            Add(12, 13);
        }
    }
}
