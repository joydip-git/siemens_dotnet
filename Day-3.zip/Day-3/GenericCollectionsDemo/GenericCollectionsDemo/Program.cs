﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericCollectionsDemo
{
    class Program
    {
        static void Main()
        {
            List<int> numbers = new List<int>
            {
                1,3,2,5,4,7,9,0,8,6,8,9
            };
            numbers.Clear();
            for (int i = 0; i < numbers.Count; i++)
            {
                Console.WriteLine(numbers[i]);
            }
            numbers.Insert(2, 12);
            Console.WriteLine("\nafter adding\n");
            //foreach (int item in numbers)
            //{
            //    Console.WriteLine(item);
            //}
            numbers.Sort();
            foreach (int item in numbers)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("\nvalues from set\n");
            HashSet<int> set = new HashSet<int> { 12, 12, 13, 14, 15, 12 };
            foreach (int item in set)
            {
                Console.WriteLine(item);
            }

            bool addedOrNot = set.Add(13);
            Console.WriteLine(addedOrNot);

            SortedList<string, List<string>> testData = new SortedList<string, List<string>>();

            testData.Add(
                "EmployeeManagementTest",
                new List<string> { "AddEmployeeTest", "CreateEmployeeTest" }
                );
            testData.Add(
                "CalculatorTest",
                new List<string> { "DivideTest", "AddTest" }
                );
            List<string> tests = testData["CalculatorTest"];
            tests.Add("MultiplyTest");

            foreach (KeyValuePair<string, List<string>> item in testData)
            {
                Console.WriteLine(item.Key);
                List<string> value = item.Value;
                value.Sort();
                Console.WriteLine("---------------------------------");
                foreach (string testMethod in value)
                {
                    Console.WriteLine(testMethod);
                }
                Console.WriteLine();
            }
        }
    }
}
