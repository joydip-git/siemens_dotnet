﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DynamicPolymorphism
{
    class Printer
    {
        public virtual void Print()
        {
            Console.WriteLine("Printer method");
        }
    }
    class LaserPrinter : Printer
    {
        //public sealed override void Print()
        public override void Print()
        {
            base.Print();
            Console.WriteLine("Laser Printer method");
        }
    }
    class OfficeLaserPrinter : LaserPrinter
    {
        public override void Print()
        {
            base.Print();
            Console.WriteLine("Office Laser Printer method");
        }
        //public new void Print()
        //{

        //}
    }
    class HomeLaserPrinter : LaserPrinter
    {
        public override void Print()
        {

        }
    }
    sealed class DeskjetPrinter : Printer
    {
        public override void Print()
        {
            
        }
    }
    class Program
    {
        static void PrintDoc(Printer printer)
        {
            printer.Print();
        }
        static void Main()
        {

            //LaserPrinter printer = new LaserPrinter();
            //PrintDoc(printer);

            OfficeLaserPrinter laserPrinter = new OfficeLaserPrinter();
            PrintDoc(laserPrinter);
        }
    }
}
