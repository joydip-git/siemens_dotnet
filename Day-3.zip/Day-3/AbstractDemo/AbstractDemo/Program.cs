﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace AbstractDemo
{
    interface IDataAccess
    {
        void GetData();
        string Path { set; get; }
    }
    abstract class DataAccess : IDataAccess//:Object
    {
        string data;
        public DataAccess()
        {

        }
        public string Data { protected set => data = value; get => data; }
        public string PrintData()
        {
            return data;
        }

        //implement
        //public virtual void GetData()
        //{

        //}
        //not implementing...at least declare the same member with public and abstract
        public abstract void GetData();
        public abstract string Path { set; get; }
    }
    class DbDataAccess : DataAccess
    {
        string dbPath;
        public DbDataAccess()
        {

        }
        public DbDataAccess(string path)
        {
            dbPath = path;
        }
        public override void GetData()
        {
            //write ADO.NET code to access data from database
            Data = "data from db";
        }
        public override string Path
        {
            get => dbPath;
            set => dbPath = value;
        }
    }
    class FileDataAccess : DataAccess
    {
        string filePath;
        public FileDataAccess()
        {

        }
        public FileDataAccess(string path)
        {
            filePath = path;
        }
        public override string Path
        {
            get => filePath; set => filePath = value;
        }

        public override void GetData()
        {
            //access data from file
            Data = "data from file";
        }
    }
    class Program
    {
        static void GetandPrintData(DataAccess dataAccess)
        {
            dataAccess.GetData();
            Console.WriteLine(dataAccess.Data);
            Console.WriteLine(dataAccess.PrintData());
        }
        static void Main(string[] args)
        {
            FileDataAccess fileDataAccess = new FileDataAccess();
            fileDataAccess.Path = "";
            GetandPrintData(fileDataAccess);

            DbDataAccess dbDataAccess = new DbDataAccess();
            dbDataAccess.Path = "";
            GetandPrintData(dbDataAccess);
        }
    }
}
