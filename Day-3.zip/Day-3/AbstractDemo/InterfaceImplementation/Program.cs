﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceImplementation
{
    class Program
    {
        static void PrintMenu()
        {
            Console.WriteLine("1. Circle");
            Console.WriteLine("2. Triangle");
        }
        static int GetChoice()
        {
            Console.Write("\nChoice[1/2]: ");
            return int.Parse(Console.ReadLine());
        }
        static IShape CreateShape(int choice)
        {
            IShape shape = null;
            switch (choice)
            {
                case 1:
                    Console.Write("\nRadius: ");
                    double radius = double.Parse(Console.ReadLine());
                    shape = new Circle(radius);
                    break;

                case 2:
                    Console.Write("\nBase: ");
                    double _base = double.Parse(Console.ReadLine());
                    Console.Write("Height: ");
                    double _height = double.Parse(Console.ReadLine());
                    shape = new Triangle(_base, _height);
                    break;

                default:
                    break;
            }
            return shape;
        }
        static void PrintArea(IShape shape)
        {
            //Type t = shape.GetType();
            //Console.WriteLine($"Area of { t.Name} is {shape.CalculateArea()}");
            Console.WriteLine($"Area of { shape.GetType().Name} is {shape.CalculateArea()}");
        }
        static void Main()
        {
            PrintMenu();
            int choice = GetChoice();
            IShape shape = CreateShape(choice);
            PrintArea(shape);
        }
    }
}
