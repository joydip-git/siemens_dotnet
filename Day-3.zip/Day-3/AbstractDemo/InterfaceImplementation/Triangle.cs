﻿namespace InterfaceImplementation
{
    class Triangle : IShape
    {
        double _tbase;
        double _theight;

        public Triangle()
        {

        }
        public Triangle(double tbase, double theight)
        {
            _tbase = tbase;
            _theight = theight;
        }
        public double Tbase { get => _tbase; set => _tbase = value; }
        public double Theight { get => _theight; set => _theight = value; }

        public double CalculateArea()
        {
            return 0.5 * _tbase * _theight;
        }
    }
}
