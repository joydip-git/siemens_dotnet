﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractImplementation
{
    class Program
    {
        static void Main()
        {
            //collection initializer - 3.0 -3.0 - 2007
            List<Person> people = new List<Person>
            {
                new Student{ Name = "anil", Subject= "CSharp", Marks = 78 },
                new Professor{ Name = "sunil", Subject= "DotNet", BooksPublished = 7 },
                new Student{ Name = "vinod", Subject= "Java", Marks = 89 },
                new Professor{ Name = "ram", Subject= "Testing", BooksPublished = 3 }
            };
            foreach (Person person in people)
            {
                Console.WriteLine(
                    person.IsOutstanding() == true ?
                    person.ToString()
                    : $"{person.Name} is not outstanding");
            }
        }
    }
}
