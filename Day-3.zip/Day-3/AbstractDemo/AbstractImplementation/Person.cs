﻿namespace AbstractImplementation
{
    public abstract class Person
    {
        string name;
        string subject;

        public Person()
        {

        }
        public Person(string name, string subject)
        {
            this.name = name;
            this.subject = subject;
        }

        public string Name { get => name; set => name = value; }
        public string Subject { get => subject; set => subject = value; }

        public abstract bool IsOutstanding();

        //object class method
        public override string ToString()
        {
            return $"Name: {name} and Subject: {subject}";
        }
    }
}
