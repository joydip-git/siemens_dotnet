﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractImplementation
{
    public class Student : Person
    {
        double marks;
        public Student()
        {

        }
        public Student(string name, string subject, double marks)
            : base(name, subject)
        {
            this.marks = marks;
        }

        public double Marks { get => marks; set => marks = value; }

        public override bool IsOutstanding()
        {
            return marks >= 85 ? true : false;
        }

        //Person class method
        public override string ToString()
        {
            return $"{base.ToString()} and Marks:{marks}";
        }
    }
}
