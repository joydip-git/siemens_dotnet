﻿namespace CalculatorAplication.BusinessLogicLayer
{
    /// <summary>
    /// class containing methods for caluclation
    /// </summary>
    public class Calculation
    {
        /// <summary>
        /// method to add two integer values
        /// </summary>
        /// <param name="first">first integer value</param>
        /// <param name="second">second integer value</param>
        /// <returns>
        /// retuns the added value, an integer
        /// </returns>
        public int Add(int first, int second)
        {
            return (first + second);
        }

        /// <summary>
        /// method to add subtract integer values from each other
        /// </summary>
        /// <param name="first">first integer value</param>
        /// <param name="second">second integer value</param>
        /// <returns>
        /// retuns the subtracted value, an integer
        /// </returns>
        public int Subtract(int first, int second)
        {
            return (first - second);
        }

        /// <summary>
        /// method to multiply two integer values
        /// </summary>
        /// <param name="first">first integer value</param>
        /// <param name="second">second integer value</param>
        /// <returns>
        /// retuns the multiplied value, an integer
        /// </returns>
        public int Multiply(int first, int second)
        {
            return (first * second);
        }

        /// <summary>
        /// method to add divide an integer value by another
        /// </summary>
        /// <param name="first">first integer value</param>
        /// <param name="second">second integer value</param>
        /// <returns>
        /// retuns the division value, an integer
        /// </returns>
        public int Divide(int first, int second)
        {
            //dividing first by second and returning the result
            return (first / second);
        }
    }
}
