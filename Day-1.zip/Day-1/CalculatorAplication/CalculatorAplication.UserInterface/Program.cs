﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CalculatorAplication.BusinessLogicLayer;

namespace CalculatorAplication.UserInterface
{
    class Program
    {
        static void PrintMenu()
        {
            Console.WriteLine("----MENU-----");
            Console.WriteLine("1. Add");
            Console.WriteLine("2. Subtract");
            Console.WriteLine("3. Multiply");
            Console.WriteLine("4. Divide");
        }
        static int GetChoice()
        {
            Console.Write("\nEnter Choice[1/2/3/4]: ");
            int choice = int.Parse(Console.ReadLine());
            return choice;
        }
        static int GetValue()
        {
            Console.Write("enter value: ");
            int value = int.Parse(Console.ReadLine());
            return value;
        }
        static char AskToContinue()
        {
            Console.WriteLine("\nTo continue enter y/Y otherwise n/N.");
            Console.Write("Enter choice[y/Y/n/N]: ");
            char temp = char.Parse(Console.ReadLine());
            return temp;
        }
        static void PerformCalculation(int choice, int first, int second, Calculation calculation)
        {
            switch (choice)
            {
                case 1:
                    int resAdd = calculation.Add(first, second);
                    Console.WriteLine($"\nAddition of {first} and {second} is {resAdd}\n");
                    break;

                case 2:
                    int resSubtract = calculation.Subtract(first, second);
                    Console.WriteLine($"\nSubtraction of {first} and {second} is {resSubtract}\n");
                    break;

                case 3:
                    int resMultiply = calculation.Multiply(first, second);
                    Console.WriteLine($"\nMultiplication of {first} and {second} is {resMultiply}\n");
                    break;

                case 4:
                    int resDivision = calculation.Divide(first, second);
                    Console.WriteLine($"\nDivision of {first} and {second} is {resDivision}\n");
                    break;

                default:
                    Console.WriteLine("\nEnter a proper choice...\n");
                    break;
            }
        }

        static void Main()
        {
            char toContinue = 'n';
            do
            {
                PrintMenu();
                int choice = GetChoice();

                int first = GetValue();
                int second = GetValue();

                Calculation calculation = new Calculation();
                PerformCalculation(choice, first, second, calculation);

                toContinue = AskToContinue();
                if (char.IsUpper(toContinue))
                {
                    toContinue = char.ToLower(toContinue);
                }

            } while (toContinue != 'n' && toContinue == 'y');
        }


    }
}
