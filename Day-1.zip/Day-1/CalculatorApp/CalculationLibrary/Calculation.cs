﻿namespace CalculationLibrary
{
    public class Calculation
    {
        public static int Add(int firstValue, int secondValue)
        {
            int resultAdd = firstValue + secondValue;
            return resultAdd;
        }
        public static int Subtract(int firstValue, int secondValue)
        {
            int subResult = firstValue - secondValue;
            return subResult;
        }
        public static int Multiply(int firstValue, int secondValue)
        {
            int multiplyResult = firstValue * secondValue;
            return multiplyResult;
        }
        public static int Divide(int firstValue, int secondValue)
        {
            int divResult = firstValue / secondValue;
            return divResult;
        }
    }
}
