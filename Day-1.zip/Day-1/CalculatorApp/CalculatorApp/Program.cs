﻿using CalculationLibrary;
using System;

namespace CalculatorApp
{
    class Program
    {
        //static void Main(string[] args)
        //static int Main(string[] args)
        //static int Main()
        static int GetValue()
        {
            Console.Write("enter value: ");
            string valueTemp = Console.ReadLine();
            int value = Convert.ToInt32(valueTemp);
            return value;
        }
        static void Main()
        {
            int first = GetValue();
            int second = GetValue();
            int resultAdd = Calculation.Add(first, second);
            Console.WriteLine($"addition of {first} and {second} is {resultAdd}");
        }
    }
}
