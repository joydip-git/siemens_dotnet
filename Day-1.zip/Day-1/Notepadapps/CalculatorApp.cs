using System;

namespace CalculatorApp
{
class Calculation
{
	static int Add(int firstValue, int secondValue)
	{
		int resultAdd = firstValue + secondValue;
		return resultAdd;
	}
	static void Subtract(int firstValue, int secondValue)
	{
		int subResult = firstValue - secondValue;
		Console.WriteLine(subResult);
	}
	static int Multiply(int firstValue, int secondValue)
	{
		int multiplyResult = firstValue * secondValue;
		return multiplyResult;
	}
	static void Divide(int firstValue, int secondValue)
	{
		int divResult = firstValue / secondValue;
		Console.WriteLine(divResult);
	}
	static void Main()
	{
		//10 --> "10" --> 10
		Console.Write("enter 1st number: ");
		string tempFirst = Console.ReadLine();
		int first = Convert.ToInt32(tempFirst);

		Console.Write("enter 2nd number: ");
		string tempSecond = Console.ReadLine();
		int second = Convert.ToInt32(tempSecond);

		int resAdd = Add(first,second);
		Console.WriteLine(resAdd);
	}
}
}