using System;

namespace ReusableComponent
{
	public class Messenger
	{
		public static string GetMessage()
		{
		return "hello from library";
		}
	}
}