using System;

namespace Conversion
{
	class Program
	{
		static void Main(string[] args)
		{
			/*
			long l = 1234567890123;
			//int a = checked((int)l);
			int a = Convert.ToInt32(l);
			Console.WriteLine(a);

			string firstTemp = "10";
			//int val = (int)firstTemp;
                        //int val = firstTemp as int;
			//int val = int.Parse(firstTemp);

			double d = double.Parse(firstTemp);
			*/
			int a = 10;
			object obj = a;
			Console.WriteLine(obj);
			
			short b = (short)((int)obj);
			
			Console.WriteLine(b);
		}
	}
}