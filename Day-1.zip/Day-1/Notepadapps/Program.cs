using System; //mscorlib.dll
using ReusableComponent; //Messenger.dll

namespace StandaloneComponent
{
	class Program
	{
		static void Main()
		{
		Console.WriteLine("hello guys...");
		string message = Messenger.GetMessage();
		Console.WriteLine(message);
		}
	}
}